<?php
$host = 'localhost';
$dbname = 'test';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $sql = 'SELECT Nummer,
                    PosX,
                    PosY,
                    Farge
               FROM stein
              ORDER BY Nummer';
	
    $q = $pdo->query($sql);
    $q->setFetchMode(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Could not connect to the database $dbname :" . $e->getMessage());
}
?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>CurlingVision</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="freehtml5.co" />

	<!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FreeHTML5.co
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<meta http-equiv="refresh" content="10" > 

	<link href="https://fonts.googleapis.com/css?family=Oxygen:300,400" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="fh5co-loader"></div>
	
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="container-wrap">
				<div class="top-menu">
					<div class="row">
						<div class="col-xs-2">
						<div id="fh5co-logo"><a href="index.php"><img src="Logo2.png" height=40px></a></div>
						</div>
						<div class="col-xs-10 text-right menu-1">
							<ul>
								<li class="active"><a href="index.php">Live</a></li>
								<li><a href="about.html">Om oss</a></li>
								<li><a href="results.html">Resultater</a></li>
								<li><a href="admin.html">Admin Side</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
	<div class="container-wrap">		
		<div id="fh5co-work">
			<div class="row">
				<div class="text-center">
					<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
					<?php $sql = "SELECT PosX, PosY FROM stein";
					$row = $q->fetch();?>
						<h2>Live Fra Trondheim</h2>
						<h3 id = "score">X - Y</h3>
					</div>
					<script>
					var team1 = <?php echo htmlspecialchars($row['PosX'])?>;
					var team2 = <?php echo htmlspecialchars($row['PosY'])?>;
					var score = document.getElementById("score");
					score.innerHTML = team1 + " - " + team2; 
					</script>
					<canvas id = "Canvas" width = "350" height="500"></canvas>
					<script>
						//var test = document.getElementById("fh5co-work");
						var canvas = document.getElementById("Canvas");
						var ctx = canvas.getContext("2d");
						//ctx.canvas.width = window.innerWidth * 0.4;
						//ctx.canvas.height = window.innerWidth * 0.4;
						ctx.fillStyle = "#ED2B2B";
						ctx.beginPath();
						ctx.arc(canvas.width/2, canvas.width/2, canvas.width*(1/2), 0, 2*Math.PI);//183
						ctx.fill();
						ctx.beginPath();
						ctx.fillStyle = "white"
						ctx.arc(canvas.width/2, canvas.width/2, canvas.width*(1/3), 0, 2*Math.PI);//183-61
						ctx.fill();
						ctx.beginPath();
						ctx.fillStyle = "#4472C4"
						ctx.arc(canvas.width/2, canvas.width/2, canvas.width*(1/6), 0, 2*Math.PI);//183-122
						ctx.fill();
						ctx.beginPath();
						ctx.fillStyle = "white"
						ctx.arc(canvas.width/2, canvas.width/2, canvas.width*0.06, 0, 2*Math.PI);//15
						ctx.fill();
						ctx.fillStyle = "black"
						ctx.moveTo(0, 0);
						ctx.lineTo(canvas.width, 0);
						ctx.stroke();
						ctx.moveTo(canvas.width/2, 0);
						ctx.lineTo(canvas.width/2, canvas.width);
						ctx.stroke();
						ctx.moveTo(0, canvas.width);
						ctx.lineTo(canvas.width, canvas.width);
						ctx.stroke();
						ctx.moveTo(0, canvas.width/2);
						ctx.lineTo(canvas.width, canvas.width/2);
						ctx.stroke();
                    </script>
                    <?php while ($row = $q->fetch()): ?>
                    <script>
                        var PosX = <?php echo htmlspecialchars($row['PosX'])?>;
                        var PosY = <?php echo htmlspecialchars($row['PosY'])?>;
                        var Farge = <?php echo htmlspecialchars($row['Farge'])?>;
                            ctx.fillStyle = "gray";
                            ctx.beginPath()
                            ctx.arc(PosX  * (canvas.width/500), PosY  * (canvas.width/500), 25 * (canvas.width/500), 0, 2*Math.PI)
                            ctx.fill()
                            if (Farge === 1) {
                                ctx.fillStyle = "#ff4555";
                            }
                            if (Farge === 2) {
                                ctx.fillStyle = "yellow";
                            }
                            ctx.beginPath()
                            ctx.arc(PosX * (canvas.width/500), PosY  * (canvas.width/500), 20  * (canvas.width/500), 0, 2*Math.PI)
                            ctx.fill()
                    </script>
                    <?php endwhile; ?>
				</div>	
			</div>
		</div>
	</div><!-- END container-wrap -->

	<div class="container-wrap">
			<footer id="fh5co-footer" role="contentinfo">
				<div class="row copyright">
					<div class="col-md-12 text-center">
						<p>
							<small class="block">&copy; Gruppe 5, innovasjonsprosjektet 2019</small> 
							<small class="block">Designet av vår fantastiske gruppe</a></small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="#"><i class="icon-twitter"></i></a></li>
								<li><a href="#"><i class="icon-facebook"></i></a></li>
								<li><a href="#"><i class="icon-linkedin"></i></a></li>
								<li><a href="#"><i class="icon-dribbble"></i></a></li>
							</ul>
						</p>
					</div>
				</div>
			</footer>
		</div><!-- END container-wrap --><!-- END container-wrap -->
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up2"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

